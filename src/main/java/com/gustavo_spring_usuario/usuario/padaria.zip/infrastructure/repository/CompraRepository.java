package com.gustavo_spring_usuario.usuario.infrastructure.repository;

import com.gustavo_spring_usuario.usuario.infrastructure.entitys.Compra;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CompraRepository extends JpaRepository<Compra, Long> {

    @Transactional
    void deleteById(Long id);

    List<Compra> findAllByUsuarioId(Integer usuarioId);

    List<Compra> findByProdutoId(Long padariaId);

    Optional<Compra> findById(Long id);

}
